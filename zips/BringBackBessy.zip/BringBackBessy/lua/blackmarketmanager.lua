function BlackMarketManager:has_unlocked_bessy()
	return true
end